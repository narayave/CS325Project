We used python for our script. It is included as change.py. To run, specify a file containing test cases and use this command:
	python change.py <input filename>
	
The input file should be formatted as such:
	[n1, n2, n3, ..., nn]
	n
	[m1, m2, m3, ..., mn]
	m
	...

(Where n and m are amounts of change, and the arrays corresponding to them are coins to be used. You must specify an array of coins above each amount of change.)