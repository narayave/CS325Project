To run our program use the following syntax:

	python tsp.py <input file> <timeout in seconds>


The timeout is an optional argument, and the result will be written to 
<input file name>.tour. The program will also print the time taken,
and the distance traveled to the console.
