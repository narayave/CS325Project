README

1. When calling the MaxSubArray.py file, make sure to include MSS_Problems.txt as an argument.
2. A Makefile has also been included. "make MaxSubArray" can be run, as long as there a MSS_Problems.txt file existent. The results are outputted to MSS_Results.txt and will be shown on screen.